const dev = require('./webpack.dev.js');

module.exports = dev;